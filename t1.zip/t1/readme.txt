Nome: Rafaela da Rosa Soares
Matr�cula: 202211338

Feitos:

1. void preenche (Aluno* vet, int i, int mat, char* nome, float nota1, float nota2, int frequencia);
2. os dados de todos os alunos do vetor;
3. o nome dos alunos que foram reprovados;
4. a matr�cula dos alunos que foram aprovados;
5. o valor m�dio das notas finais da turma;
6. a quantidade de alunos que ficou abaixo do valor m�dio das notas finais da turma;
7. a quantidade de alunos que reprovou por frequ�ncia;
8. o nome dos alunos que foram aprovados e que ficaram acima do valor m�dio das notas finais da
turma;
9. o nome do(s) aluno(s) que obteve (obtiveram) a maior nota final;
10. a matr�cula do(s) aluno(s) que obteve (obtiveram) a menor nota 2
